package com.etezaz.assessment_task_magma.view;

import android.view.View;

/**
 * Created by Etezaz Abo Al-Izam on 10/29/2020.
 * Automata4Group
 * etezazizam44@gmail.com
 */
public interface OnItemClickListener {
    void onItemClick(String id, String URL, View v);

}
